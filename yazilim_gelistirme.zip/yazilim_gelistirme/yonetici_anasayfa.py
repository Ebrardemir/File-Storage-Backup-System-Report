import os
import tkinter as tk

os.chdir("C:\\Users\\ebrar\\OneDrive\\Masaüstü\\yazilim_gelistirme\\")

def kullanicilar():
    os.system(f"python kullanicilar.py")

def sifre_degistirme_istekleri():
    os.system(f"python sifre_degistirme_istekleri.py")

def loglar():
    os.system(f"python yonetici_log.py")

pencere = tk.Tk()
pencere.geometry("400x400")
pencere.title("Yonetici Ana Sayfası")

frame = tk.Frame(pencere)
frame.place(relx=0.5, rely=0.5, anchor="center")  # Ortalamak için relx ve rely kullanılıyor

# Profilim butonu
tk.Button(frame, text="Kullanicilar", command=kullanicilar).grid(row=0, column=0, pady=10, padx=10, sticky="ew")

tk.Button(frame, text="sifre degistirme istekleri", command=sifre_degistirme_istekleri).grid(row=1, column=0, pady=10, padx=10, sticky="ew")

tk.Button(frame, text="tüm logları görüntüle", command=loglar).grid(row=2, column=0, pady=10, padx=10, sticky="ew")


# Pencere döngüsü
pencere.mainloop()
