import tkinter as tk
import os
from hashlib import sha256
from mysql_baglanti import create_connection  # baglantı.py dosyasını içe aktar
from mysql.connector import Error
import subprocess
import datetime

os.chdir("C:\\Users\\ebrar\\OneDrive\\Masaüstü\\yazilim_gelistirme\\")
dosya_izleyici_yolu = r"C:\\Users\\ebrar\\OneDrive\\Masaüstü\\yazilim_gelistirme\\dosya_izleme.py"

def log_yaz(baslangic_tarihi, bitis_tarihi, islem_turu, durum,kullanici_adi="", kaynak_dizin="", veri_miktari=0):
    """
    Giriş işlemi hakkında log kaydı oluşturur.
    """
    logs_klasoru = "logs"
    log_dosyasi = os.path.join(logs_klasoru, "giris_log.txt")

    # Logs klasörü yoksa oluştur
    if not os.path.exists(logs_klasoru):
        os.makedirs(logs_klasoru)

    # Log mesajını oluştur
    log_mesaji = (
        f"Başlangıç Tarihi: {baslangic_tarihi}, "
        f"Bitiş Tarihi: {bitis_tarihi}, "
        f"İşlem Türü: {islem_turu}, "
        f"Durum: {durum}, "
        f"Kullanıcı Adı: {kullanici_adi}, "
        f"Kaynak Dizin: {kaynak_dizin}, "
        f"Yedeklenen Veri Miktarı: {veri_miktari} byte\n"
    )

    # Log dosyasına yaz
    with open(log_dosyasi, "a", encoding="utf-8") as log_file:
        log_file.write(log_mesaji)

def giris_yap():
    # İşlem başlangıç tarihi
    baslangic_tarihi = datetime.datetime.now()
    
    # Kullanıcıdan alınan verileri al
    kullanici = kullanici_adi.get()
    parola = parola_alani.get()

    # Boş alanları kontrol et
    if not kullanici or not parola:
        hata_mesaji.config(text="Tüm alanlar doldurulmalıdır!", fg="red")
        log_yaz(baslangic_tarihi, datetime.datetime.now(), "Giriş", "Başarısız: Eksik Alan",kullanici_adi=kullanici)
        return

    # Şifreyi SHA-256 ile hash'le
    parola_hash = sha256(parola.encode('utf-8')).hexdigest()

    # Veritabanı bağlantısını oluştur
    connection = create_connection()

    if connection:
        try:
            cursor = connection.cursor()
            query = "SELECT id, parola, rol, is_pasif FROM kullanicilar WHERE kullanici_adi = %s"
            cursor.execute(query, (kullanici,))
            result = cursor.fetchone()

            if result:
                # Veritabanındaki hash ile kullanıcı tarafından girilen şifreyi karşılaştır
                stored_hash = result[1]
                kullanici_id = result[0]
                rol = result[2]
                is_pasif = result[3]
                
                if is_pasif == 1:
                    hata_mesaji.config(text="Hesabınız aktif değil!", fg="red")
                    log_yaz(baslangic_tarihi, datetime.datetime.now(), "Giriş", "Başarısız: Hesap Pasif",kullanici_adi=kullanici)
                    return

                if stored_hash == parola_hash:
                    print("Giriş başarılı!")
                    hata_mesaji.config(text="Giriş başarılı!", fg="green")
                    log_yaz(baslangic_tarihi, datetime.datetime.now(), "Giriş", "Başarılı",kullanici_adi=kullanici)
                    
                    # Giriş başarılıysa, ana sayfayı aç
                    if rol == 1:
                        pencere.destroy()  # Pencereyi kapat
                        os.system(f"python kullanici_anasayfa.py {kullanici_id}")
                    else:
                        pencere.destroy()  # Pencereyi kapat
                        os.system(f"python yonetici_anasayfa.py {kullanici_id}")
                else:
                    hata_mesaji.config(text="Yanlış şifre!", fg="red")
                    log_yaz(baslangic_tarihi, datetime.datetime.now(), "Giriş", "Başarısız: Yanlış Şifre",kullanici_adi=kullanici)
            else:
                hata_mesaji.config(text="Kullanıcı adı bulunamadı!", fg="red")
                log_yaz(baslangic_tarihi, datetime.datetime.now(), "Giriş", "Başarısız: Kullanıcı Bulunamadı")
        except Error as e:
            hata_mesaji.config(text="Veritabanı hatası!", fg="red")
            log_yaz(baslangic_tarihi, datetime.datetime.now(), "Giriş", f"Hata: {e}",kullanici_adi=kullanici)
        finally:
            connection.close()

# Tkinter arayüzü
pencere = tk.Tk()
pencere.geometry("400x400")
pencere.title("Giriş Yap")

frame = tk.Frame(pencere)
frame.place(relx=0.5, rely=0.5, anchor="center")  # Ortalamak için relx ve rely kullanılıyor

tk.Label(frame, text="Kullanıcı Adı").grid(row=0, column=0, pady=10, padx=10)
kullanici_adi = tk.Entry(frame)  # entry textbox gibi
kullanici_adi.grid(row=0, column=1, pady=10, padx=10)

# Parola etiketi ve giriş alanı
tk.Label(frame, text="Parola").grid(row=1, column=0, pady=10, padx=10)
parola_alani = tk.Entry(frame, show="*")
parola_alani.grid(row=1, column=1, pady=10, padx=10)

# Giriş yap butonu
tk.Button(frame, text="Giriş Yap", command=giris_yap).grid(row=2, column=0, columnspan=2, pady=10)

# Kayıt Ol butonu
tk.Button(frame, text="Kayit Ol", command=lambda: os.system(f"python kayit_ol.py")).grid(row=3, column=3, columnspan=2, pady=10)

# Hata mesajı için etiket
hata_mesaji = tk.Label(frame, text="", fg="red")
hata_mesaji.grid(row=3, column=0, columnspan=2)

subprocess.Popen(["python", dosya_izleyici_yolu])

# Burada başka işlemler yapabilirsiniz
print("Dosya izleyici başlatıldı.")

# Pencere döngüsü
pencere.mainloop()
