from hashlib import sha256
import sys
import tkinter as tk
from tkinter import messagebox

from mysql_baglanti import create_connection

kullanici_adi = sys.argv[1]

# Veritabanı bağlantısını oluştur
connection = create_connection()

if connection:
    cursor = connection.cursor()
    query = "SELECT parola, is_pasif, depolama_boyut FROM kullanicilar WHERE kullanici_adi = %s"
    cursor.execute(query, (kullanici_adi,))
    result = cursor.fetchone()

    if result:
        # Veritabanındaki hash ile kullanıcı tarafından girilen şifreyi karşılaştır
        parola = result[0]
        is_pasif = result[1]
        depolama_boyut = result[2]

# Dosya boyutunu güncelleyen fonksiyon
def dosya_boyutu_guncelle():
    try:
        yeni_boyut = int(dosya_boyutu_entry.get())  # Kullanıcının girdiği değeri al
        # Veritabanını güncelle
        connection = create_connection()
        if connection:
            cursor = connection.cursor()
            query = "UPDATE kullanicilar SET depolama_boyut = %s WHERE kullanici_adi = %s"
            cursor.execute(query, (yeni_boyut, kullanici_adi))
            connection.commit()
            connection.close()

            # Güncelleme başarılı olduğunda bilgi mesajı
            messagebox.showinfo("Başarılı", f"Dosya boyutu başarıyla {yeni_boyut} olarak güncellendi.")
        else:
            messagebox.showerror("Hata", "Veritabanı bağlantısı sağlanamadı.")
    except ValueError:
        messagebox.showerror("Hata", "Lütfen geçerli bir dosya boyutu girin.")

# Pencereyi oluştur
pencere = tk.Tk()
pencere.geometry("450x400+600+300")
pencere.title("Kullanıcı Bilgileri")

# Kullanıcı Adı Label
kullanici_adi_label = tk.Label(pencere, text=f"Kullanıcı Adı: {kullanici_adi}")
kullanici_adi_label.pack(pady=10)

# Şifre Label
sifre_label = tk.Label(pencere, text=f"Şifre: {parola}")
sifre_label.pack(pady=10)

# Aktiflik Durumu Label
aktiflik_durumu_label = tk.Label(pencere, text=f"Durum: {'Aktif' if is_pasif == 0 else 'Pasif'}")
aktiflik_durumu_label.pack(pady=10)

# Dosya Boyutu Label (KB cinsinden)
dosya_boyutu_label = tk.Label(pencere, text=f"Dosya Boyutu: {depolama_boyut} Byte")
dosya_boyutu_label.pack(pady=10)

# Yeni Dosya Boyutu için Label ve Entry
dosya_boyutu_label_entry = tk.Label(pencere, text="Yeni Dosya Boyutunu Girin (Byte):")
dosya_boyutu_label_entry.pack(pady=5)
dosya_boyutu_entry = tk.Entry(pencere)
dosya_boyutu_entry.pack(pady=5)

# Dosya Boyutunu Güncelle Butonu
dosya_boyutu_button = tk.Button(pencere, text="Dosya Boyutunu Güncelle", command=dosya_boyutu_guncelle)
dosya_boyutu_button.pack(pady=10)

# Pencereyi çalıştır
pencere.mainloop()
