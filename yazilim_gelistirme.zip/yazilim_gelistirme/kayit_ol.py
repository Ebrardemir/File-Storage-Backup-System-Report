import tkinter as tk
import os
from hashlib import sha256
from mysql_baglanti import create_connection  # baglantı.py dosyasını içe aktar
from mysql.connector import Error
import datetime

os.chdir("C:\\Users\\ebrar\\OneDrive\\Masaüstü\\yazilim_gelistirme\\")

def log_yaz(baslangic_tarihi, bitis_tarihi, islem_turu, durum, kullanici_adi="",kaynak_dizin="", veri_miktari=0):
    """
    Kayıt işlemi hakkında log kaydı oluşturur.
    """
    logs_klasoru = "logs"
    log_dosyasi = os.path.join(logs_klasoru, "kayit_log.txt")

    # Logs klasörü yoksa oluştur
    if not os.path.exists(logs_klasoru):
        os.makedirs(logs_klasoru)

    # Log mesajını oluştur
    log_mesaji = (
        f"Başlangıç Tarihi: {baslangic_tarihi}, "
        f"Bitiş Tarihi: {bitis_tarihi}, "
        f"İşlem Türü: {islem_turu}, "
        f"Durum: {durum}, "
        f"Kullanıcı Adı: {kullanici_adi}, "
        f"Kaynak Dizin: {kaynak_dizin}, "
        f"Yedeklenen Veri Miktarı: {veri_miktari} byte\n"
    )

    # Log dosyasına yaz
    with open(log_dosyasi, "a", encoding="utf-8") as log_file:
        log_file.write(log_mesaji)

def kayit_ol():
    # İşlem başlangıç tarihi
    baslangic_tarihi = datetime.datetime.now()

    # Kullanıcıdan alınan verileri al
    isim = isim_alani.get()
    kullanici = kullanici_adi.get()
    parola = parola_alani.get()

    # Boş alanları kontrol et
    if not isim or not kullanici or not parola:
        hata_mesaji.config(text="Tüm alanlar doldurulmalıdır!", fg="red")
        log_yaz(baslangic_tarihi, datetime.datetime.now(), "Kayıt", "Başarısız: Eksik Alan",kullanici_adi=kullanici)
        return

    # Şifreyi SHA-256 ile hash'le
    parola_hash = sha256(parola.encode('utf-8')).hexdigest()

    # Veritabanı bağlantısını oluştur
    connection = create_connection()

    if connection:
        try:
            # Kullanıcı adı ile veritabanında bir kullanıcı var mı diye kontrol et
            cursor = connection.cursor()
            query = "SELECT COUNT(*) FROM kullanicilar WHERE kullanici_adi = %s"
            cursor.execute(query, (kullanici,))
            result = cursor.fetchone()

            if result[0] > 0:
                # Eğer kullanıcı adı zaten varsa
                hata_mesaji.config(text="Bu kullanıcı adı zaten alınmış!", fg="red")
                log_yaz(baslangic_tarihi, datetime.datetime.now(), "Kayıt", "Başarısız: Kullanıcı Adı Alınmış")
            else:
                # Kullanıcı bilgilerini veritabanına ekle
                query = "INSERT INTO kullanicilar (isim, kullanici_adi, parola, rol, is_pasif) VALUES (%s, %s, %s, 1, 0)"
                values = (isim, kullanici, parola_hash)
                cursor.execute(query, values)
                connection.commit()

                # Başarılı kayıt
                hata_mesaji.config(text="Kayıt başarılı!", fg="green")
                log_yaz(baslangic_tarihi, datetime.datetime.now(), "Kayıt", "Başarılı", kullanici_adi=kullanici,kaynak_dizin=os.getcwd(), veri_miktari=len(parola))

                # Alanları temizle
                isim_alani.delete(0, tk.END)
                kullanici_adi.delete(0, tk.END)
                parola_alani.delete(0, tk.END)

                # Giriş dosyasını çalıştır
                pencere.destroy()  # Pencereyi kapat
                os.system("python giris.py")

        except Error as e:
            hata_mesaji.config(text="Bir hata meydana geldi!", fg="red")
            log_yaz(baslangic_tarihi, datetime.datetime.now(), "Kayıt", f"Hata: {e}")
        finally:
            if connection.is_connected():
                connection.close()

# Tkinter arayüzü
pencere = tk.Tk()
pencere.geometry("400x400")
pencere.title("Kayıt Ol")

frame = tk.Frame(pencere)
frame.place(relx=0.5, rely=0.5, anchor="center")  # Ortalamak için relx ve rely kullanılıyor

tk.Label(frame, text="İsim").grid(row=0, column=0, pady=10, padx=10)
isim_alani = tk.Entry(frame)  # entry textbox gibi
isim_alani.grid(row=0, column=1, pady=10, padx=10)

# Kullanıcı adı etiketi ve giriş alanı
tk.Label(frame, text="Kullanıcı Adı").grid(row=1, column=0, pady=10, padx=10)
kullanici_adi = tk.Entry(frame)  # entry textbox gibi
kullanici_adi.grid(row=1, column=1, pady=10, padx=10)

# Parola etiketi ve giriş alanı
tk.Label(frame, text="Parola").grid(row=2, column=0, pady=10, padx=10)
parola_alani = tk.Entry(frame, show="*")
parola_alani.grid(row=2, column=1, pady=10, padx=10)

# Kayıt ol butonu
tk.Button(frame, text="Kayıt Ol", command=kayit_ol).grid(row=3, column=3, columnspan=2, pady=10)

# Hata mesajı için etiket
hata_mesaji = tk.Label(frame, text="", fg="red")
hata_mesaji.grid(row=4, column=0, columnspan=2)

# Pencere döngüsü
pencere.mainloop()
