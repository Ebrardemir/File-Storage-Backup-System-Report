import os
import sys
import tkinter as tk
from tkinter import messagebox
import shutil

from mysql_baglanti import create_connection

# Takım ID'si komut satırından alınacak
takim_id = sys.argv[2]
kullanici_id = sys.argv[1]


def kullanici_adi():
    """Veritabanından kullanıcı adını getir."""
    connection = create_connection()
    cursor = connection.cursor()
    query = "SELECT kullanici_adi FROM kullanicilar WHERE id = %s"
    cursor.execute(query, (kullanici_id,))
    result = cursor.fetchone()
    connection.close()
    return result[0] if result else None


def dosya_duzenle():
    """Dosyayı düzenleme işlemi."""
    try:
        # Takım ID'sine ait klasör yolunu belirleme
        hedef_klasor = os.path.join("dosyalar", str(takim_id))
        if not os.path.exists(hedef_klasor):
            messagebox.showerror("Hata", "Takıma ait dosya bulunamadı!")
            return

        # Klasördeki txt dosyalarını listeleme
        txt_dosyalar = [f for f in os.listdir(hedef_klasor) if f.endswith(".txt")]

        if not txt_dosyalar:
            messagebox.showerror("Hata", "Hiç dosya bulunamadı!")
            return

        # Dosya Listesi (Listbox) içini temizle ve dosyaları ekle
        dosya_listesi.delete(0, tk.END)
        for dosya in txt_dosyalar:
            dosya_listesi.insert(tk.END, dosya)

    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")


def dosya_sec_ve_duzenle():
    """Seçilen dosyanın içeriğini metin kutusuna yükle."""
    try:
        secili_dosya = dosya_listesi.get(tk.ACTIVE)
        if not secili_dosya:
            messagebox.showerror("Hata", "Bir dosya seçmediniz!")
            return

        # Takım ID'si ile dosya yolunu oluştur
        hedef_klasor = os.path.join("dosyalar", str(takim_id))
        dosya_yolu = os.path.join(hedef_klasor, secili_dosya)

        if not os.path.exists(dosya_yolu):
            messagebox.showerror("Hata", "Dosya bulunamadı!")
            return

        # Dosyanın içeriğini oku
        with open(dosya_yolu, "r", encoding="utf-8") as dosya:
            icerik = dosya.read()

        # İçeriği metin kutusuna yükle
        text_box.delete(1.0, tk.END)
        text_box.insert(tk.END, icerik)

    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")


def dosya_kaydet():
    """Düzenlenen dosyayı kaydet."""
    try:
        secili_dosya = dosya_listesi.get(tk.ACTIVE)
        if not secili_dosya:
            messagebox.showerror("Hata", "Bir dosya seçmediniz!")
            return

        # Takım ID'si ile dosya yolunu oluştur
        hedef_klasor = os.path.join("dosyalar", str(takim_id))
        dosya_yolu = os.path.join(hedef_klasor, secili_dosya)

        # Düzenlenen içeriği al
        icerik = text_box.get(1.0, tk.END)

        # Dosyayı kaydet
        with open(dosya_yolu, "w", encoding="utf-8") as dosya:
            dosya.write(icerik.strip())  # strip() ile fazla boşlukları temizle

        messagebox.showinfo("Başarılı", f"Dosya başarıyla kaydedildi: {dosya_yolu}")

    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")




def dosya_senkronizasyonu():
    """Seçili dosyayı kullanıcı adıyla oluşturulacak klasöre kopyala."""
    try:
        secili_dosya = dosya_listesi.get(tk.ACTIVE)
        if not secili_dosya:
            messagebox.showerror("Hata", "Bir dosya seçmediniz!")
            return

        # Kullanıcı adını al
        kullanici_adi_str = kullanici_adi()
        if not kullanici_adi_str:
            messagebox.showerror("Hata", "Kullanıcı adı alınamadı!")
            return

        # Kullanıcı adıyla klasör oluşturulacak
        kullanici_klasor = os.path.join("dosyalar", kullanici_adi_str)

        # Eğer kullanıcı klasörü yoksa oluştur
        os.makedirs(kullanici_klasor, exist_ok=True)

        # Dosya yolunu oluştur
        hedef_dosya_yolu = os.path.join(kullanici_klasor, secili_dosya)

        # Takım klasöründeki dosyanın tam yolunu oluştur
        takim_klasor = os.path.join("dosyalar", str(takim_id))
        dosya_yolu = os.path.join(takim_klasor, secili_dosya)

        # Dosya zaten varsa, kullanıcıya uyarı ver
        if os.path.exists(hedef_dosya_yolu):
            if not messagebox.askyesno("Onay", f"{secili_dosya} dosyası zaten var. Üzerine yazmak istiyor musunuz?"):
                return  # Kullanıcı "Hayır" derse işlemi iptal et

        # Dosyayı kopyala
        shutil.copy(dosya_yolu, hedef_dosya_yolu)

        messagebox.showinfo("Başarılı", f"Dosya başarıyla senkronize edildi: {hedef_dosya_yolu}")

    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")




# Tkinter GUI başlatma
pencere = tk.Tk()
pencere.geometry("600x600+600+300")
pencere.title("Takım ID'si ile Dosya İşlemleri")

frame = tk.Frame(pencere)
frame.place(relx=0.5, rely=0.5, anchor="center")  # Ortalamak için relx ve rely kullanılıyor

# Dosya Listesi (Listbox)
dosya_listesi = tk.Listbox(frame, width=40, height=10)
dosya_listesi.grid(row=0, column=0, pady=10, padx=10)
dosya_duzenle()
# Dosya Düzenle butonu
tk.Button(frame, text="Dosya Düzenle", command=dosya_sec_ve_duzenle).grid(row=2, column=0, pady=10, padx=10, sticky="ew")

# Dosya Senkronizasyonu butonu
tk.Button(frame, text="Dosya Senkronize Et", command=dosya_senkronizasyonu).grid(row=5, column=0, pady=10, padx=10, sticky="ew")

# Metin Kutusu (Text Box)
text_box = tk.Text(frame, width=40, height=10)
text_box.grid(row=3, column=0, pady=10, padx=10)

# Kaydet butonu
tk.Button(frame, text="Kaydet", command=dosya_kaydet).grid(row=4, column=0, pady=10, padx=10, sticky="ew")

# Pencereyi başlat
pencere.mainloop()
