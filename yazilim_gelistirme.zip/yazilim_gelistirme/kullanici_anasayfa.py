import os
import sys
import tkinter as tk

kullanici_id = sys.argv[1]
os.chdir("C:\\Users\\ebrar\\OneDrive\\Masaüstü\\yazilim_gelistirme\\")

def profilim():
    os.system(f"python kullanici_profil.py {kullanici_id}")

def takimlarim():
    os.system(f"python takimlarim.py {kullanici_id}")

def takim_olustur():
    os.system(f"python takim_olustur.py {kullanici_id}")

def dosya_islemleri():
    os.system(f"python dosya_islemleri.py {kullanici_id}")

# Kullanıcı ana sayfası
pencere = tk.Tk()
pencere.geometry("400x400")
pencere.title("Kullanıcı Ana Sayfası")

frame = tk.Frame(pencere)
frame.place(relx=0.5, rely=0.5, anchor="center")  # Ortalamak için relx ve rely kullanılıyor

# Profilim butonu
tk.Button(frame, text="Profilim", command=profilim).grid(row=0, column=0, pady=10, padx=10, sticky="ew")

# Takımlarım butonu
tk.Button(frame, text="Takımlarım", command=takimlarim).grid(row=1, column=0, pady=10, padx=10, sticky="ew")

# Takım Oluştur butonu
tk.Button(frame, text="Takım Oluştur", command=takim_olustur).grid(row=2, column=0, pady=10, padx=10, sticky="ew")

# Dosya İşlemleri butonu
tk.Button(frame, text="Dosya İşlemleri", command=dosya_islemleri).grid(row=3, column=0, pady=10, padx=10, sticky="ew")

# Pencere döngüsü
pencere.mainloop()
