import os
import sys
import tkinter as tk
from tkinter import messagebox
from mysql_baglanti import create_connection  # Veritabanı bağlantısı için

# Global kullanıcı ID'si
kullanici_id = sys.argv[1] # Bu, oturum açmış kullanıcının ID'si
os.chdir("C:\\Users\\ebrar\\OneDrive\\Masaüstü\\yazilim_gelistirme\\")

def kullanicinin_takimlarini_goster():
    """Kullanıcının olduğu tüm takımları listele."""
    try:
        # Veritabanı bağlantısını oluştur
        connection = create_connection()
        cursor = connection.cursor()

        # Kullanıcının olduğu takımları almak için sorgu
        query = "SELECT takim_id FROM takim_uyeler WHERE uye_id = %s"
        cursor.execute(query, (kullanici_id,))
        takimlar = cursor.fetchall()  # Kullanıcının olduğu takımların ID'leri

        connection.close()

        # Eğer takım varsa, listbox'ı doldur
        if takimlar:
            for takim in takimlar:
                takim_listesi.insert(tk.END, f"Takım ID: {takim[0]}")
        else:
            messagebox.showinfo("Bilgi", "Kullanıcının bulunduğu takım bulunamadı.")
    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")

def takim_sec():
    """Seçilen takımı al ve takim_islemleri.py'ye gönder."""
    selected_item = takim_listesi.curselection()  # Seçilen öğeyi al
    if selected_item:
        takim_id = takim_listesi.get(selected_item[0]).split(":")[1].strip()  # Takım ID'sini al
        os.system(f"python takim_islemleri.py {kullanici_id} {takim_id}")  # Kullanıcı ve takım ID'si ile dosyayı çalıştır
    else:
        messagebox.showwarning("Uyarı", "Lütfen bir takım seçin.")

def takim_islemleri():
    """Seçilen takımı al ve takim_islemleri.py'ye gönder."""
    selected_item = takim_listesi.curselection()  # Seçilen öğeyi al
    if selected_item:
        takim_id = takim_listesi.get(selected_item[0]).split(":")[1].strip()  # Takım ID'sini al
        os.system(f"python takim_islemleri.py {kullanici_id} {takim_id}")  # Kullanıcı ve takım ID'si ile dosyayı çalıştır
    else:
        messagebox.showwarning("Uyarı", "Lütfen bir takım seçin.")

def takima_dosya_yukle():
    """Seçilen takımı al ve takim_islemleri.py'ye gönder."""
    selected_item = takim_listesi.curselection()  # Seçilen öğeyi al
    if selected_item:
        takim_id = takim_listesi.get(selected_item[0]).split(":")[1].strip()  # Takım ID'sini al
        os.system(f"python takima_dosya_yukle.py {kullanici_id} {takim_id}")  # Kullanıcı ve takım ID'si ile dosyayı çalıştır
    else:
        messagebox.showwarning("Uyarı", "Lütfen bir takım seçin.")

# Kullanıcı ana sayfası
pencere = tk.Tk()
pencere.geometry("700x400+600+300")
pencere.title("Kullanıcı Ana Sayfası")

frame = tk.Frame(pencere)
frame.place(relx=0.5, rely=0.5, anchor="center")  # Ortalamak için relx ve rely kullanılıyor

# Takım Listesi
takim_listesi = tk.Listbox(frame, height=10, width=50)
takim_listesi.grid(row=0, column=0, pady=10, padx=10)

# Kullanıcının takımlarını göster
kullanicinin_takimlarini_goster()

# Dosya İşlemleri butonu
tk.Button(frame, text="Takım dosyaları düzenle", command=takim_sec).grid(row=3, column=0, pady=10, padx=10, sticky="ew")


# Dosya İşlemleri butonu
tk.Button(frame, text="Takıma dosya yükle", command=takima_dosya_yukle).grid(row=4, column=0, pady=10, padx=10, sticky="ew")

# Pencere döngüsü
pencere.mainloop()
