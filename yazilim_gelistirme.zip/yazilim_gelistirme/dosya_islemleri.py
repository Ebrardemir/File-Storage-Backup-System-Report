import os
import sys
import tkinter as tk
from tkinter import filedialog, messagebox
from mysql_baglanti import create_connection

kullanici_id = sys.argv[1]


def kullanici_adi():
    """Veritabanından kullanıcı adını getir."""
    connection = create_connection()
    cursor = connection.cursor()
    query = "SELECT kullanici_adi FROM kullanicilar WHERE id = %s"
    cursor.execute(query, (kullanici_id,))
    result = cursor.fetchone()
    connection.close()
    return result[0] if result else None


def dosya_yukle():
    """Dosya yükleme işlemi."""
    try:
        username = kullanici_adi()
        if not username:
            messagebox.showerror("Hata", "Kullanıcı adı bulunamadı!")
            return

        # Kullanıcı depolama bilgilerini getir
        connection = create_connection()
        cursor = connection.cursor()
        query = """
            SELECT depolama_boyut, dosya_boyut 
            FROM kullanicilar 
            WHERE id = %s
        """
        cursor.execute(query, (kullanici_id,))
        result = cursor.fetchone()
        connection.close()

        if not result:
            messagebox.showerror("Hata", "Kullanıcı bilgileri bulunamadı!")
            return

        depolama_boyut, dosya_boyut = result

        # Yalnızca .txt dosyalarını seçmek için dosya seçici
        dosya_yolu = filedialog.askopenfilename(
            title="Dosya Seç",
            filetypes=(("Metin Dosyaları", "*.txt"), ("Tüm Dosyalar", "*.*"))
        )

        if not dosya_yolu:
            return  # Kullanıcı bir dosya seçmediyse işlemi iptal et

        # Dosyanın boyutunu öğren
        dosya_boyutu = os.path.getsize(dosya_yolu)

        # Dosya boyutunu kontrol et
        if dosya_boyut + dosya_boyutu > depolama_boyut:
            messagebox.showerror("Hata", "Dosya yükleme hakkınız doldu!")
            return

        # Kullanıcıya özel klasör oluşturma
        hedef_klasor = os.path.join("dosyalar", username)
        os.makedirs(hedef_klasor, exist_ok=True)

        # Seçilen dosyayı klasöre kaydet
        hedef_dosya_yolu = os.path.join(hedef_klasor, os.path.basename(dosya_yolu))

        # Seçilen dosyayı hedefe kopyala
        with open(dosya_yolu, "r", encoding="utf-8") as kaynak_dosya:
            icerik = kaynak_dosya.read()

        with open(hedef_dosya_yolu, "w", encoding="utf-8") as hedef_dosya:
            hedef_dosya.write(icerik)

        # Veritabanındaki dosya_boyut değerini güncelle
        connection = create_connection()
        cursor = connection.cursor()
        update_query = """
            UPDATE kullanicilar 
            SET dosya_boyut = dosya_boyut + %s 
            WHERE id = %s
        """
        cursor.execute(update_query, (dosya_boyutu, kullanici_id))
        connection.commit()
        connection.close()

        messagebox.showinfo("Başarılı", f"Dosya başarıyla kaydedildi: {hedef_dosya_yolu}")

    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")


def dosya_duzenle():
    """Dosyayı düzenleme işlemi."""
    try:
        username = kullanici_adi()
        if not username:
            messagebox.showerror("Hata", "Kullanıcı adı bulunamadı!")
            return

        # Kullanıcıya ait dosyalar
        hedef_klasor = os.path.join("dosyalar", username)
        if not os.path.exists(hedef_klasor):
            messagebox.showerror("Hata", "Kullanıcıya ait dosya bulunamadı!")
            return

        # Dosyaların listesini al
        txt_dosyalar = [f for f in os.listdir(hedef_klasor) if f.endswith(".txt")]

        if not txt_dosyalar:
            messagebox.showerror("Hata", "Hiç dosya bulunamadı!")
            return

        # Dosyaları Listbox'a ekle
        dosya_listesi.delete(0, tk.END)  # Önceki listeyi temizle
        for dosya in txt_dosyalar:
            dosya_listesi.insert(tk.END, dosya)

    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")


def dosya_sec_ve_duzenle():
    """Seçilen dosyanın içeriğini metin kutusuna yükle."""
    try:
        secili_dosya = dosya_listesi.get(tk.ACTIVE)
        if not secili_dosya:
            messagebox.showerror("Hata", "Bir dosya seçmediniz!")
            return

        username = kullanici_adi()
        if not username:
            messagebox.showerror("Hata", "Kullanıcı adı bulunamadı!")
            return

        # Dosya yolunu oluştur
        hedef_klasor = os.path.join("dosyalar", username)
        dosya_yolu = os.path.join(hedef_klasor, secili_dosya)

        if not os.path.exists(dosya_yolu):
            messagebox.showerror("Hata", "Dosya bulunamadı!")
            return

        # Dosyanın içeriğini oku
        with open(dosya_yolu, "r", encoding="utf-8") as dosya:
            icerik = dosya.read()

        # İçeriği metin kutusuna yaz
        text_box.delete(1.0, tk.END)  # Metin kutusunu temizle
        text_box.insert(tk.END, icerik)

    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")


def dosya_kaydet():
    """Düzenlenen dosyayı kaydet."""
    try:
        secili_dosya = dosya_listesi.get(tk.ACTIVE)
        if not secili_dosya:
            messagebox.showerror("Hata", "Bir dosya seçmediniz!")
            return

        username = kullanici_adi()
        if not username:
            messagebox.showerror("Hata", "Kullanıcı adı bulunamadı!")
            return

        # Dosya yolunu oluştur
        hedef_klasor = os.path.join("dosyalar", username)
        dosya_yolu = os.path.join(hedef_klasor, secili_dosya)

        # Düzenlenen içeriği al
        icerik = text_box.get(1.0, tk.END)

        # Dosyayı kaydet
        with open(dosya_yolu, "w", encoding="utf-8") as dosya:
            dosya.write(icerik.strip())  # strip() ile fazla boşlukları temizle

        messagebox.showinfo("Başarılı", f"Dosya başarıyla kaydedildi: {dosya_yolu}")

    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")


# Kullanıcı ana sayfası
pencere = tk.Tk()
pencere.geometry("700x700+600+300")
pencere.title("Kullanıcı Dosya Islemleri")

frame = tk.Frame(pencere)
frame.place(relx=0.5, rely=0.5, anchor="center")  # Ortalamak için relx ve rely kullanılıyor

# Dosya Listesi (Listbox)
dosya_listesi = tk.Listbox(frame, width=40, height=10)
dosya_listesi.grid(row=0, column=0, pady=10, padx=10)

# Dosya Yükle butonu
tk.Button(frame, text="Dosya Yükle", command=dosya_yukle).grid(row=1, column=0, pady=10, padx=10, sticky="ew")

# Dosya Düzenle butonu
tk.Button(frame, text="Dosya Düzenle", command=dosya_sec_ve_duzenle).grid(row=2, column=0, pady=10, padx=10, sticky="ew")

# Metin Kutusu (Text Box)
text_box = tk.Text(frame, width=40, height=10)
text_box.grid(row=3, column=0, pady=10, padx=10)
dosya_duzenle()
# Kaydet butonu
tk.Button(frame, text="Kaydet", command=dosya_kaydet).grid(row=4, column=0, pady=10, padx=10, sticky="ew")

# Pencereyi başlat
pencere.mainloop()
