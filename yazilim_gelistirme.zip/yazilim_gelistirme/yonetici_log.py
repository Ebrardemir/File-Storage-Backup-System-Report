import os
import tkinter as tk
from tkinter import ttk, messagebox
from tkinter.scrolledtext import ScrolledText

def list_files():
    """Loglar klasöründeki tüm .txt dosyalarını listeleyen fonksiyon."""
    log_dir = "logs"  # Loglar klasörünün yolu
    if not os.path.exists(log_dir):
        messagebox.showerror("Hata", f"{log_dir} klasörü bulunamadı!")
        return []
    return [f for f in os.listdir(log_dir) if f.endswith(".txt")]

def open_file():
    """Seçilen dosyayı açar ve içeriğini gösterir."""
    selected_file = file_listbox.get(file_listbox.curselection())
    if not selected_file:
        messagebox.showwarning("Uyarı", "Lütfen bir dosya seçin!")
        return

    file_path = os.path.join("logs", selected_file)
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            file_content = file.read()
        text_area.delete(1.0, tk.END)  # Mevcut metni temizle
        text_area.insert(tk.END, file_content)  # Dosya içeriğini göster
    except Exception as e:
        messagebox.showerror("Hata", f"Dosya açılamadı: {str(e)}")

# Ana pencere oluştur
root = tk.Tk()
root.title("Log Görüntüleyici")
root.geometry("600x400")

# Log dosyalarının listesi için bir liste kutusu
file_listbox = tk.Listbox(root, selectmode=tk.SINGLE, height=10, width=50)
file_listbox.pack(pady=10)

# Log dosyalarını listele
files = list_files()
if files:
    for file in files:
        file_listbox.insert(tk.END, file)
else:
    file_listbox.insert(tk.END, "Hiçbir .txt dosyası bulunamadı!")

# Aç butonu
open_button = ttk.Button(root, text="Dosyayı Aç", command=open_file)
open_button.pack(pady=5)

# Dosya içeriği için metin kutusu (ScrolledText)
text_area = ScrolledText(root, wrap=tk.WORD, width=70, height=15)
text_area.pack(pady=10)

# Uygulama döngüsü
root.mainloop()