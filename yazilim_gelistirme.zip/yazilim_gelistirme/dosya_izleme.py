import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import yedekleme  # Yedekleme fonksiyonunu import ediyoruz

class DosyaIzleyici(FileSystemEventHandler):
    def __init__(self, yedekler_dizini):
        self.yedekler_dizini = yedekler_dizini

    def on_modified(self, event):
        """
        Dosya değiştiğinde çağrılacak fonksiyon.
        """
        if event.is_directory:
            return  # Dizin değişikliği yapılmışsa işlem yapma
        
        print(f"Dosya değiştirildi: {event.src_path}")
        
        # Yedekleme işlemi başlatılıyor
        yedekleme.dosya_yedekle(event.src_path, self.yedekler_dizini)

    def on_created(self, event):
        """
        Yeni dosya oluşturulduğunda çağrılacak fonksiyon.
        """
        if event.is_directory:
            return  # Dizin oluşturulmuşsa işlem yapma
        
        print(f"Yeni dosya oluşturuldu: {event.src_path}")
        
        # Yedekleme işlemi başlatılıyor
        yedekleme.dosya_yedekle(event.src_path, self.yedekler_dizini)

    def on_deleted(self, event):
        """
        Dosya silindiğinde çağrılacak fonksiyon.
        """
        if event.is_directory:
            return  # Dizin silinmişse işlem yapma
        
        print(f"Dosya silindi: {event.src_path}")
        
        # Yedekleme işlemi başlatılıyor
        yedekleme.dosya_yedekle(event.src_path, self.yedekler_dizini)

# İzleme işlemi için dizin tanımlaması
dosya_klasoru = "dosyalar"  # İzlemek istediğiniz dizin
yedekler_dizini = "yedekler"  # Yedekleme dosyalarının saklanacağı dizin

# Observer oluştur
event_handler = DosyaIzleyici(yedekler_dizini)
observer = Observer()
observer.schedule(event_handler, dosya_klasoru, recursive=True)

# İzleme başlatma
observer.start()
print(f"{dosya_klasoru} dizini izleniyor... Çıkmak için Ctrl+C kullanın.")

try:
    while True:
        time.sleep(1)  # İzleme sürekli devam eder
except KeyboardInterrupt:
    observer.stop()  # Çıkışta observer'ı durdur
observer.join()
