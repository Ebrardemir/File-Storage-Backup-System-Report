import os
import tkinter as tk
from tkinter import messagebox
from mysql_baglanti import create_connection  # Veritabanı bağlantısı için

os.chdir("C:\\Users\\ebrar\\OneDrive\\Masaüstü\\yazilim_gelistirme\\")

def kullanicilar():
    try:
        connection = create_connection()
        if connection:
            cursor = connection.cursor()
            query = "SELECT id, kullanici_adi FROM kullanicilar"
            cursor.execute(query)
            kullanicilar = cursor.fetchall()
            connection.close()

            kullanici_listesi.delete(0, tk.END)  # Listeyi temizle

            if kullanicilar:
                for kullanici in kullanicilar:
                    kullanici_listesi.insert(tk.END, f"{kullanici[0]} - {kullanici[1]}")
            else:
                messagebox.showinfo("Bilgi", "Kullanıcı bulunamadı.")
        else:
            messagebox.showerror("Hata", "Veritabanı bağlantısı sağlanamadı.")
    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")

def kullanici_sec():
    selected_item = kullanici_listesi.curselection()
    if selected_item:
        selected_user = kullanici_listesi.get(selected_item[0])
        id, kullanici_adi = selected_user.split(" - ")
        return id, kullanici_adi
    else:
        messagebox.showwarning("Uyarı", "Lütfen bir kullanıcı seçin.")
        return False

def kullanici_profili():
    kullanici_adi = kullanici_sec()
    if kullanici_adi:
        os.system(f"python yonetici_kullanici_profili.py {kullanici_adi[1]}")  # Kullanıcı adı ile işlem yap
    else:
        return False


def kullanici_pasif_et():
    kullanici = kullanici_sec()
    if kullanici:
        kullanici_adi = kullanici[1]  # Kullanıcı adını al
        try:
            connection = create_connection()
            if connection:
                cursor = connection.cursor()
                query = "UPDATE kullanicilar SET is_pasif = 1 WHERE kullanici_adi = %s"
                cursor.execute(query, (kullanici_adi,))
                connection.commit()
                connection.close()
                messagebox.showinfo("Bilgi", f"{kullanici_adi} başarıyla pasif yapıldı.")
                kullanicilar()  # Listeyi güncelle
            else:
                messagebox.showerror("Hata", "Veritabanı bağlantısı sağlanamadı.")
        except Exception as e:
            messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")

def kullanici_aktif_et():
    kullanici = kullanici_sec()
    if kullanici:
        kullanici_adi = kullanici[1]  # Kullanıcı adını al
        try:
            connection = create_connection()
            if connection:
                cursor = connection.cursor()
                query = "UPDATE kullanicilar SET is_pasif = 0 WHERE kullanici_adi = %s"
                cursor.execute(query, (kullanici_adi,))
                connection.commit()
                connection.close()
                messagebox.showinfo("Bilgi", f"{kullanici_adi} başarıyla aktif yapıldı.")
                kullanicilar()  # Listeyi güncelle
            else:
                messagebox.showerror("Hata", "Veritabanı bağlantısı sağlanamadı.")
        except Exception as e:
            messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")


def kullanici_dosya_goruntule():
    kullanici = kullanici_sec()  # ID ve kullanıcı adı tuple olarak dönecek
    if kullanici:
        id = kullanici[0]  # ID'yi tuple'dan al
        os.system(f"python yonetici_kullanici_dosya_gorme.py {id}")  # ID'yi kullanarak işlem yap
    else:
        return False

# Kullanıcı ana sayfası
pencere = tk.Tk()
pencere.geometry("700x400+600+300")
pencere.title("Kullanıcı Ana Sayfası")

frame = tk.Frame(pencere)
frame.place(relx=0.5, rely=0.5, anchor="center")

# Kullanıcı Listesi
kullanici_listesi = tk.Listbox(frame, height=10, width=50)
kullanici_listesi.grid(row=0, column=0, pady=10, padx=10)

# Kullanıcıları listele
kullanicilar()

# İşlem Butonları
tk.Button(frame, text="Kullanıcı profilini görüntüle", command=kullanici_profili).grid(row=3, column=0, pady=10, padx=10, sticky="ew")
tk.Button(frame, text="Kullanıcıyı pasif et", command=kullanici_pasif_et).grid(row=4, column=0, pady=10, padx=10, sticky="ew")
tk.Button(frame, text="Kullanıcıyı aktif et", command=kullanici_aktif_et).grid(row=5, column=0, pady=10, padx=10, sticky="ew")
tk.Button(frame, text="Kullanıcı Dosyalarını GÖrüntüle", command=kullanici_dosya_goruntule).grid(row=6, column=0, pady=10, padx=10, sticky="ew")


# Pencere döngüsü
pencere.mainloop()
