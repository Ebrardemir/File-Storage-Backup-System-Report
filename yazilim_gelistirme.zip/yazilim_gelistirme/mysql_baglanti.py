import mysql.connector
from mysql.connector import Error

def create_connection():
    try:
        # Bağlantı oluştur
        connection = mysql.connector.connect(
            host='localhost',  # MySQL sunucu adresi
            database='kullanici_db',  # Veritabanı adı
            user='Ebrar',  # Kullanıcı adı
            password='1'  # Şifre
        )
        
        if connection.is_connected():
            print("MySQL veritabanına başarıyla bağlanıldı!")
        return connection
    except Error as e:
        print(f"Hata meydana geldi: {e}")
        return None
