import os
import shutil
import datetime
import threading

def dosya_yedekle(dosya_yolu, yedek_dizini):
    """
    Verilen dosyayı belirtilen yedek dizinine tarih ve saat ekleyerek kopyalar.
    """
    def yedekleme_islemi():
        # Log dosyasının yolu
        logs_klasoru = "logs"
        log_dosyasi = os.path.join(logs_klasoru, "yedekleme_log.txt")
        
        # Log klasörü yoksa oluştur
        if not os.path.exists(logs_klasoru):
            os.makedirs(logs_klasoru)
        
        # Dosya adını al
        dosya_adi = os.path.basename(dosya_yolu)
        
        # Şu anki tarihi ve saati al
        baslangic_zamani = datetime.datetime.now()
        su_an = baslangic_zamani.strftime("%Y%m%d_%H%M%S")
        
        # Yeni dosya adı oluştur (tarih + dosya adı)
        yeni_dosya_adi = f"{su_an}_{dosya_adi}"
        
        # Yedek dosya yolunu oluştur
        yedek_dosya_yolu = os.path.join(yedek_dizini, yeni_dosya_adi)
        
        try:
            if not os.path.exists(yedek_dizini):
                os.makedirs(yedek_dizini)
            
            shutil.copy2(dosya_yolu, yedek_dosya_yolu)  # Dosyayı yedek dizinine kopyalar
            bitis_zamani = datetime.datetime.now()
            
            # Dosya boyutunu al
            veri_miktari = os.path.getsize(dosya_yolu)
            
            # Log kaydı oluştur
            log_mesaji = (
                f"Başlangıç Tarihi: {baslangic_zamani}, "
                f"Bitiş Tarihi: {bitis_zamani}, "
                f"İşlem Türü: Yedekleme, "
                f"Durum: Başarılı, "
                f"Kaynak Dizin: {dosya_yolu}, "
                f"Yedeklenen Veri Miktarı: {veri_miktari} byte\n"
            )
            print(f"Yedeklendi: {yeni_dosya_adi}")
        except Exception as e:
            bitis_zamani = datetime.datetime.now()
            log_mesaji = (
                f"Başlangıç Tarihi: {baslangic_zamani}, "
                f"Bitiş Tarihi: {bitis_zamani}, "
                f"İşlem Türü: Yedekleme, "
                f"Durum: Hata, "
                f"Kaynak Dizin: {dosya_yolu}, "
                f"Hata Mesajı: {e}\n"
            )
            print(f"Yedekleme hatası: {e}")
        
        # Log dosyasına yaz
        with open(log_dosyasi, "a", encoding="utf-8") as log_file:
            log_file.write(log_mesaji)

    # Thread oluşturup başlatıyoruz
    thread = threading.Thread(target=yedekleme_islemi)
    thread.start()
