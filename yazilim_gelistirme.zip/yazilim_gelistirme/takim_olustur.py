import sys
import tkinter as tk
from tkinter import messagebox
from mysql_baglanti import create_connection  # Veritabanı bağlantısı için
import os
from datetime import datetime

# Global kullanıcı ID'si
kullanici_id = sys.argv[1]

def tum_kullanicilari_getir():
    """Veritabanından tüm kullanıcıları getir, ancak belirli bir kullanıcıyı hariç tut."""  
    try:
        connection = create_connection()
        cursor = connection.cursor()
        query = "SELECT id, kullanici_adi FROM kullanicilar WHERE id != %s"  # Belirli bir kullanıcıyı hariç tut
        cursor.execute(query, (kullanici_id,))
        users = cursor.fetchall()  # Tüm kullanıcıları al
        connection.close()
        return users
    except Exception as e:
        messagebox.showerror("Hata", f"Veritabanı hatası: {str(e)}")
        return []

def tum_kullanicilari_goster():
    """Tüm kullanıcıları Listbox'ta göster."""
    try:
        # Kullanıcıları veritabanından al
        users = tum_kullanicilari_getir()

        # Eğer kullanıcı varsa, listbox'ı doldur
        if users:
            for user in users:
                # user[0] id, user[1] kullanici_adi
                user_text = f"{user[0]} - {user[1]}"
                kullanici_listesi.insert(tk.END, user_text)
        else:
            messagebox.showinfo("Bilgi", "Hiç kullanıcı bulunamadı.")
    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")

def log_islem(tur, durum, takim_id, selected_users, takim_kurucu_id=None):
    """Log işlemi: İşlem bilgilerini bir log dosyasına kaydet."""
    try:
        # Log klasörü yoksa oluştur
        log_klasor = "logs"
        if not os.path.exists(log_klasor):
            os.makedirs(log_klasor)

        # Log dosyası ismi
        log_dosya_yolu = os.path.join(log_klasor, "takim_log.txt")

        # Log kaydını oluştur
        log_zamani = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        selected_users_ids = [str(kullanici_listesi.get(i).split(" - ")[0]) for i in selected_users]
        takim_kurucu_id_str = str(takim_kurucu_id) if takim_kurucu_id else "Bilinmiyor"
        log_metni = f"{log_zamani} | İşlem Türü: {tur} | Durum: {durum} | Takım ID: {takim_id} | Takım Kurucusu: {takim_kurucu_id_str} | Üyeler: {', '.join(selected_users_ids)}\n"

        # Log dosyasına yaz
        with open(log_dosya_yolu, "a", encoding="utf-8") as log_dosya:
            log_dosya.write(log_metni)

    except Exception as e:
        messagebox.showerror("Hata", f"Log kaydedilirken bir hata oluştu: {str(e)}")


def takim_olustur():
    """Seçilen kullanıcılarla bir takım oluştur."""
    try:
        # Seçilen kullanıcıları al
        selected_users = kullanici_listesi.curselection()
        if not selected_users:
            messagebox.showwarning("Uyarı", "Takım oluşturmak için en az bir kullanıcı seçmelisiniz.")
            log_islem("Takım Oluşturma", "Başarısız - Kullanıcı seçilmedi", None, [], kullanici_id)
            return

        # Veritabanına yeni takım ekle
        connection = create_connection()
        cursor = connection.cursor()
        query_takim_ekle = "INSERT INTO takimlar (takim_kurucu_id) VALUES (%s)"
        cursor.execute(query_takim_ekle, (kullanici_id,))  # Takım kurucusu olarak mevcut kullanıcıyı ekliyoruz
        takim_id = cursor.lastrowid  # Yeni takımın ID'sini al

        # Takım kurucusunu takim_uyeler tablosuna ekle
        query_uyeleri_ekle = "INSERT INTO takim_uyeler (takim_id, uye_id) VALUES (%s, %s)"
        cursor.execute(query_uyeleri_ekle, (takim_id, kullanici_id))  # Takım kurucusunu da ekliyoruz

        # Seçilen kullanıcıları takim_uyeler tablosuna ekle
        for user_index in selected_users:
            user_id = int(kullanici_listesi.get(user_index).split(" - ")[0])  # ID'yi al
            cursor.execute(query_uyeleri_ekle, (takim_id, user_id))  # Kullanıcıyı takıma ekle
        connection.commit()

        messagebox.showinfo("Başarılı", f"Takım başarıyla oluşturuldu! Takım ID: {takim_id}")
        log_islem("Takım Oluşturma", "Başarılı", takim_id, selected_users, kullanici_id)
        connection.close()

    except Exception as e:
        messagebox.showerror("Hata", f"Takım oluşturulurken bir hata oluştu: {str(e)}")
        log_islem("Takım Oluşturma", "Başarısız - Hata oluştu", None, [], kullanici_id)


# Kullanıcı ana sayfası
pencere = tk.Tk()
pencere.geometry("700x400+600+300")
pencere.title("Kullanıcı Ana Sayfası")

frame = tk.Frame(pencere)
frame.place(relx=0.5, rely=0.5, anchor="center")  # Ortalamak için relx ve rely kullanılıyor

# Kullanıcı Listesi
kullanici_listesi = tk.Listbox(frame, height=10, width=50, selectmode=tk.MULTIPLE)  # Birden fazla seçim yapılabilir
kullanici_listesi.grid(row=0, column=0, pady=10, padx=10)

tum_kullanicilari_goster()

# Takım oluştur butonu
tk.Button(frame, text="Takım Oluştur", command=takim_olustur).grid(row=2, column=0, pady=10, padx=10, sticky="ew")

# Pencere döngüsü
pencere.mainloop()
