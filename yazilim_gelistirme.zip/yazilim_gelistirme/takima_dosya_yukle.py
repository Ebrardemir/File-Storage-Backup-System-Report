import os
import sys
import tkinter as tk
from tkinter import messagebox
from datetime import datetime
from mysql_baglanti import create_connection

# Takım ID'si komut satırından alınacak
takim_id = sys.argv[2]
kullanici_id = sys.argv[1]

LOG_DIZINI = "logs"
LOG_DOSYASI = os.path.join(LOG_DIZINI, "takima_dosya_yukle_log.txt")

# Log klasörü ve dosyasını oluştur
os.makedirs(LOG_DIZINI, exist_ok=True)

if not os.path.exists(LOG_DOSYASI):
    with open(LOG_DOSYASI, "w", encoding="utf-8") as log:
        log.write("Başlangıç Tarihi, Bitiş Tarihi, İşlem Türü, Durum Kodu, Kaynak Dizini, Veri Miktarı (bytes)\n")

def log_yaz(baslangic, bitis, islem_turu, durum_kodu, kaynak_dizin, veri_miktari):
    """Log dosyasına bilgi yaz."""
    with open(LOG_DOSYASI, "a", encoding="utf-8") as log:
        log.write(f"{baslangic}, {bitis}, {islem_turu}, {durum_kodu}, {kaynak_dizin}, {veri_miktari}\n")

def kullanici_adi():
    """Veritabanından kullanıcı adını getir."""
    connection = create_connection()
    cursor = connection.cursor()
    query = "SELECT kullanici_adi FROM kullanicilar WHERE id = %s"
    cursor.execute(query, (kullanici_id,))
    result = cursor.fetchone()
    connection.close()
    return result[0] if result else None

def dosya_yukle():
    """Dosya yükleme işlemi."""
    try:
        kullanici_adii = kullanici_adi()
        kullanici_klasoru = os.path.join("dosyalar", str(kullanici_adii))
        
        if not os.path.exists(kullanici_klasoru):
            messagebox.showerror("Hata", "Kullanıcı klasörü bulunamadı!")
            return

        dosyalar = [f for f in os.listdir(kullanici_klasoru) if f.endswith(".txt")]

        if not dosyalar:
            messagebox.showerror("Hata", "Klasörde hiç dosya bulunamadı!")
            return

        dosya_listesi.delete(0, tk.END)
        for dosya in dosyalar:
            dosya_listesi.insert(tk.END, dosya)

    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")

def dosya_sec_ve_yukle():
    """Seçilen dosyanın içeriğini metin kutusuna yükle ve hedef klasöre kaydet."""
    baslangic_tarihi = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        secili_dosya = dosya_listesi.get(tk.ACTIVE)
        if not secili_dosya:
            messagebox.showerror("Hata", "Bir dosya seçmediniz!")
            return

        kullanici_adii = kullanici_adi()
        kullanici_klasoru = os.path.join("dosyalar", str(kullanici_adii))
        dosya_yolu = os.path.join(kullanici_klasoru, secili_dosya)

        if not os.path.exists(dosya_yolu):
            messagebox.showerror("Hata", "Dosya bulunamadı!")
            return

        with open(dosya_yolu, "r", encoding="utf-8") as dosya:
            icerik = dosya.read()

        hedef_klasor = os.path.join("dosyalar", str(takim_id))
        os.makedirs(hedef_klasor, exist_ok=True)

        hedef_dosya_yolu = os.path.join(hedef_klasor, secili_dosya)
        with open(hedef_dosya_yolu, "w", encoding="utf-8") as hedef_dosya:
            hedef_dosya.write(icerik)

        veri_miktari = os.path.getsize(dosya_yolu)
        bitis_tarihi = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        log_yaz(baslangic_tarihi, bitis_tarihi, "Dosya Yükleme", "Başarılı", dosya_yolu, veri_miktari)

        messagebox.showinfo("Başarılı", f"Dosya başarıyla kaydedildi: {hedef_dosya_yolu}")

    except Exception as e:
        bitis_tarihi = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_yaz(baslangic_tarihi, bitis_tarihi, "Dosya Yükleme", f"Hata: {str(e)}", dosya_yolu, 0)
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")

# Tkinter GUI başlatma
pencere = tk.Tk()
pencere.geometry("600x600+600+300")
pencere.title("Takım ID'si ile Dosya İşlemleri")

frame = tk.Frame(pencere)
frame.place(relx=0.5, rely=0.5, anchor="center")

dosya_listesi = tk.Listbox(frame, width=40, height=10)
dosya_listesi.grid(row=0, column=0, pady=10, padx=10)
dosya_yukle()

tk.Button(frame, text="Seç ve Yükle", command=dosya_sec_ve_yukle).grid(row=2, column=0, pady=10, padx=10, sticky="ew")

pencere.mainloop()
