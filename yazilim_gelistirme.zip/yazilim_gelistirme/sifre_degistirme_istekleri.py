import os
import sys
import tkinter as tk
from tkinter import messagebox
from mysql_baglanti import create_connection  # Veritabanı bağlantısı için
from datetime import datetime

# Global kullanıcı ID'si
os.chdir("C:\\Users\\ebrar\\OneDrive\\Masaüstü\\yazilim_gelistirme\\")

LOG_DOSYASI = "logs/sifre_degisiklik_onay_red_log.txt"

# Log dosyasını kontrol et ve yoksa oluştur
if not os.path.exists("logs"):
    os.makedirs("logs")

def log_yaz(islem_turu, durum_kodu, kaynak_dizin, yedeklenen_veri_miktari):
    baslangic_tarihi = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    bitis_tarihi = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    log_bilgisi = (
        f"\nBaşlangıç Tarihi: {baslangic_tarihi}\n"
        f"Bitiş Tarihi: {bitis_tarihi}\n"
        f"Yapılan İşlem: {islem_turu}\n"
        f"İşlem Durumu: {durum_kodu}\n"
        f"Kaynak Dizin: {kaynak_dizin}\n"
        f"Yedeklenen Veri Miktarı: {yedeklenen_veri_miktari}\n"
    )

    with open(LOG_DOSYASI, "a", encoding="utf-8") as log_dosya:
        log_dosya.write(log_bilgisi)

def kullanicilar():
    try:
        connection = create_connection()
        if connection:
            cursor = connection.cursor()
            query = "SELECT kullanici_adi FROM kullanicilar WHERE sifre_degistirme_istegi = %s"
            cursor.execute(query, (1,))
            kullanicilar = cursor.fetchall()
            connection.close()

            kullanici_listesi.delete(0, tk.END)  # Listeyi temizle

            if kullanicilar:
                for kullanici in kullanicilar:
                    kullanici_listesi.insert(tk.END, f"{kullanici[0]}")
            else:
                messagebox.showinfo("Bilgi", "Şifre değiştirme isteği olan kullanıcı bulunamadı.")
        else:
            messagebox.showerror("Hata", "Veritabanı bağlantısı sağlanamadı.")
    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {str(e)}")

def sifre_degistirme_durumu_guncelle(kullanici_adi, durum):
    try:
        connection = create_connection()
        if connection:
            cursor = connection.cursor()
            query = "UPDATE kullanicilar SET sifre_degistirme_istegi = %s WHERE kullanici_adi = %s"
            cursor.execute(query, (durum, kullanici_adi))
            connection.commit()
            connection.close()

            # Log yazma
            islem_turu = "Onay" if durum == 2 else "Red"
            durum_kodu = "2 - Onaylandı" if durum == 2 else "3 - Reddedildi"
            kaynak_dizin = f"Kullanıcı Adı: {kullanici_adi}"
            yedeklenen_veri_miktari = "0B"

            log_yaz(islem_turu, durum_kodu, kaynak_dizin, yedeklenen_veri_miktari)
            return True
        else:
            return False
    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {e}")
        return False

def sifre_onayla():
    selected_item = kullanici_listesi.curselection()
    if selected_item:
        kullanici_adi = kullanici_listesi.get(selected_item[0])
        if sifre_degistirme_durumu_guncelle(kullanici_adi, 2):
            messagebox.showinfo("Başarılı", f"Kullanıcı adı: {kullanici_adi} için şifre değiştirme isteği onaylandı.")
            kullanicilar()
    else:
        messagebox.showwarning("Uyarı", "Lütfen bir kullanıcı seçin.")

def sifre_reddet():
    selected_item = kullanici_listesi.curselection()
    if selected_item:
        kullanici_adi = kullanici_listesi.get(selected_item[0])
        if sifre_degistirme_durumu_guncelle(kullanici_adi, 3):
            messagebox.showinfo("Başarılı", f"Kullanıcı adı: {kullanici_adi} için şifre değiştirme isteği reddedildi.")
            kullanicilar()
    else:
        messagebox.showwarning("Uyarı", "Lütfen bir kullanıcı seçin.")

pencere = tk.Tk()
pencere.geometry("700x400+600+300")
pencere.title("Yönetici Sifre İslemleri")

frame = tk.Frame(pencere)
frame.place(relx=0.5, rely=0.5, anchor="center")

# Kullanıcı Listesi
kullanici_listesi = tk.Listbox(frame, height=10, width=50)
kullanici_listesi.grid(row=0, column=0, pady=10, padx=10)

# Kullanıcıların şifre değiştirme isteklerini listele
kullanicilar()

# İşlem Butonları
tk.Button(frame, text="Şifre Değiştirme İsteğini Onayla", command=sifre_onayla).grid(row=3, column=0, pady=10, padx=10, sticky="ew")
tk.Button(frame, text="Şifre Değiştirme İsteğini Reddet", command=sifre_reddet).grid(row=4, column=0, pady=10, padx=10, sticky="ew")

# Pencere döngüsü
pencere.mainloop()
