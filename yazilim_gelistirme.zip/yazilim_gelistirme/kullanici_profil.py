from hashlib import sha256
import sys
import os  # Klasör işlemleri için
import tkinter as tk
from tkinter import messagebox
from mysql_baglanti import create_connection  # Veritabanı bağlantısı için
from datetime import datetime

# Global kullanıcı ID'si
kullanici_id = sys.argv[1]

# Klasörlerin bulunduğu ana dizin
KLASOR_DIZINI = "dosyalar"  # Burayı doğru dizinle değiştirin
LOG_DOSYASI = "logs/sifre_degisiklik_talep_log.txt"

# Log kaydı oluştur
if not os.path.exists("logs"):
    os.makedirs("logs")

def log_yaz(islem_turu, durum_kodu, kaynak_dizin):
    baslangic_tarihi = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    bitis_tarihi = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    log_bilgisi = (
        f"\nBaşlangıç Tarihi: {baslangic_tarihi}\n"
        f"Bitiş Tarihi: {bitis_tarihi}\n"
        f"Yapılan İşlem: {islem_turu}\n"
        f"İşlem Durumu: {durum_kodu}\n"
        f"Kaynak Dizin: {kaynak_dizin}\n"
    )

    with open(LOG_DOSYASI, "a", encoding="utf-8") as log_dosya:
        log_dosya.write(log_bilgisi)


# Kullanıcı bilgilerini veritabanından al
def kullanici_bilgilerini_getir():
    try:
        # Veritabanı bağlantısını oluştur
        connection = create_connection()

        if connection:
            cursor = connection.cursor()
            query = "SELECT kullanici_adi FROM kullanicilar WHERE id = %s"
            cursor.execute(query, (kullanici_id,))
            result = cursor.fetchone()

            if result:
                return result[0]
            else:
                print("Kullanıcı bulunamadı!")
                return None
        else:
            print("Veritabanı bağlantısı sağlanamadı.")
            return None
    except Exception as e:
        print(f"Hata oluştu: {e}")
        return None

# Kullanıcı adı ve şifresini değiştirme işlemi
def kullanici_adi_degistir():
    yeni_kullanici_adi = yeni_kullanici_adi_alani.get()
    eski_kullanici_adi = kullanici_bilgilerini_getir()

    if yeni_kullanici_adi and eski_kullanici_adi:
        # Veritabanı bağlantısını oluştur
        connection = create_connection()

        if connection:
            try:
                cursor = connection.cursor()

                # Yeni kullanıcı adı veritabanında zaten var mı kontrol et
                cursor.execute("SELECT COUNT(*) FROM kullanicilar WHERE kullanici_adi = %s", (yeni_kullanici_adi,))
                result = cursor.fetchone()

                if result[0] > 0:
                    messagebox.showwarning("Uyarı", "Bu kullanıcı adı zaten mevcut. Lütfen farklı bir kullanıcı adı girin.")
                    return

                # Kullanıcı adını güncelleme sorgusu
                query = "UPDATE kullanicilar SET kullanici_adi = %s WHERE id = %s"
                cursor.execute(query, (yeni_kullanici_adi, kullanici_id))
                connection.commit()  # Veritabanına kaydet

                # Klasör adını değiştir
                eski_klasor_yolu = os.path.join(KLASOR_DIZINI, eski_kullanici_adi)
                yeni_klasor_yolu = os.path.join(KLASOR_DIZINI, yeni_kullanici_adi)

                if os.path.exists(eski_klasor_yolu):
                    os.rename(eski_klasor_yolu, yeni_klasor_yolu)
                    messagebox.showinfo("Başarılı", f"Klasör adı {eski_kullanici_adi} -> {yeni_kullanici_adi} olarak değiştirildi.")
                else:
                    messagebox.showwarning("Uyarı", f"{eski_klasor_yolu} klasörü bulunamadı.")

                # Güncelleme başarılı mesajı
                messagebox.showinfo("Başarılı", "Kullanıcı adı başarıyla değiştirildi.")
            except Exception as e:
                messagebox.showerror("Hata", f"Bir hata oluştu: {e}")
            finally:
                cursor.close()
                connection.close()
        else:
            messagebox.showerror("Hata", "Veritabanı bağlantısı sağlanamadı.")
    else:
        messagebox.showwarning("Uyarı", "Lütfen geçerli bir kullanıcı adı girin.")

# Şifre değiştirme isteği gönderme işlemi
def sifre_degistir():
    yeni_sifre_ = yeni_sifre.get()

    if yeni_sifre_:
        # Veritabanı bağlantısını oluştur
        connection = create_connection()
        
        if connection:
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT sifre_degistirme_istegi FROM kullanicilar WHERE id = %s", (kullanici_id,))
                result = cursor.fetchone()

                if result[0]==1:
                    messagebox.showwarning("Uyarı", "Sifre değiştirme istegi henuz onaylanmadı.")
                    return
                    
                elif result[0]==0:
                    messagebox.showwarning("Uyarı", "Sifre değiştirme istegi gönderiniz.")
                    return
                parola_hash = sha256(yeni_sifre_.encode('utf-8')).hexdigest()
                # Kullanıcı adını güncelleme sorgusu
                query = "UPDATE kullanicilar SET parola = %s, sifre_degistirme_istegi = 0 WHERE id = %s"
                cursor.execute(query, (parola_hash, kullanici_id))
                connection.commit()  # Veritabanına kaydet

                # Güncelleme başarılı mesajı
                messagebox.showinfo("Başarılı", "Sifre başarıyla değiştirildi.")
            except Exception as e:
                messagebox.showerror("Hata", f"Bir hata oluştu: {e}")
            finally:
                cursor.close()
                connection.close()
        else:
            messagebox.showerror("Hata", "Veritabanı bağlantısı sağlanamadı.")
    else:
        messagebox.showwarning("Uyarı", "Lütfen geçerli bir sifre girin.")

def sifre_degistirme_istegi():

        connection = create_connection()

        if connection:
            
            try:
                cursor = connection.cursor()
                # Yeni kullanıcı adı veritabanında zaten var mı kontrol et
                cursor.execute("SELECT sifre_degistirme_istegi FROM kullanicilar WHERE id = %s", (kullanici_id,))
                result = cursor.fetchone()

                if result[0]==1:
                    messagebox.showwarning("Uyarı", "Sifre değiştirme istegi daha önce gönderildi.")
                    return
                    
                elif result[0]==2:
                    messagebox.showwarning("Uyarı", "Sifre değiştirme isteginiz onaylandı, şifreyi değiştirebilirsiniz.")
                    return
                # Kullanıcı adını güncelleme sorgusu
                query = "UPDATE kullanicilar SET sifre_degistirme_istegi = %s WHERE id = %s"
                cursor.execute(query, (1, kullanici_id))
                connection.commit()  # Veritabanına kaydet

                # Log yazma
                kaynak_dizin = os.path.join(KLASOR_DIZINI, kullanici_bilgilerini_getir())
                log_yaz(
                    islem_turu="Parola Değiştirme Talebi",
                    durum_kodu="1 - Talep Gönderildi",
                    kaynak_dizin=kaynak_dizin,

                )
                # Güncelleme başarılı mesajı
                messagebox.showinfo("Başarılı", "Sifre değiştirme istegi basarıyla gönderildi.")
            except Exception as e:
                messagebox.showerror("Hata", f"Bir hata oluştu: {e}")
            finally:
                cursor.close()
                connection.close()
        else:
            messagebox.showerror("Hata", "Veritabanı bağlantısı sağlanamadı.")

# Kullanıcı profil sayfası
pencere = tk.Tk()
pencere.geometry("400x400")
pencere.title("Kullanıcı Profili")

frame = tk.Frame(pencere)
frame.place(relx=0.5, rely=0.5, anchor="center")  # Ortalamak için relx ve rely kullanılıyor

# Kullanıcı adı değiştirme
tk.Label(frame, text="Yeni Kullanıcı Adı:").grid(row=0, column=0, pady=10, padx=10)
yeni_kullanici_adi_alani = tk.Entry(frame)
yeni_kullanici_adi_alani.grid(row=0, column=1, pady=10, padx=10)

# Kullanıcı adı değiştirme butonu
tk.Button(frame, text="Kullanıcı Adı Değiştir", command=kullanici_adi_degistir).grid(row=1, column=0, columnspan=2, pady=10)
tk.Label(frame, text="Yeni Sifre:").grid(row=2, column=0, pady=10, padx=10)
yeni_sifre = tk.Entry(frame)
yeni_sifre.grid(row=2, column=1, pady=10, padx=10)
# Şifre değiştirme isteği gönderme butonu
tk.Button(frame, text="Şifre Değiştir", command=sifre_degistir).grid(row=3, column=0, columnspan=2, pady=10)

tk.Button(frame, text="Şifre Değiştirme Istegi", command=sifre_degistirme_istegi).grid(row=4, column=0, columnspan=2, pady=10)

# Pencere döngüsü
pencere.mainloop()
